SiteMesh 3: Official repository
=========

Current version: 3.0.1

Available for download on Maven Central here:

http://central.maven.org/maven2/org/sitemesh/sitemesh/3.0.1/

Documentation:

http://wiki.sitemesh.org/wiki/display/sitemesh3