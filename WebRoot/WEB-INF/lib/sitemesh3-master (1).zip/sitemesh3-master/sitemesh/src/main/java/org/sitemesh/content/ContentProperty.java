package org.sitemesh.content;

/**
 * @author Joe Walnes
 */
public interface ContentProperty extends TreeNode<ContentProperty>, ContentChunk {

}
